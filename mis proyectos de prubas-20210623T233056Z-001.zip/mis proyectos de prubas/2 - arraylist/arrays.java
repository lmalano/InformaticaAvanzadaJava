import java.util.ArrayList; //para usaar array

public class arrays
{
    public ArrayList<String> nombres; //un arrays de tipo string llamado nombres
    public ArrayList<Integer> numeros;     //un arrays de tipo string llamado numeros
    /**
     * Constructor for objects of class arrays
     */
    public void misnombres()
    {
       // nombres = new ArrayList<String>();
        numeros=new ArrayList<Integer>();
    }
    
    public ArrayList<String> get(){
        return nombres;
    }
    
    public void misnumeros()
    {
        numeros = new ArrayList<Integer>();
    }
    
    public void añadirnombre(String n)
    {
       
        nombres.add(n);
        
    }

   public void añadirnumeros(int numerosb)
   {numeros.add(numerosb);
    
    }
    
   public String getnombres(int a)
   {
    return nombres.get(a);
    }

   public int getnumeros(int b)//analoga aplicado a numeros
   {return numeros.get(b);
    
    }
  
   public boolean elem(String a)
   {return nombres.contains(a);}
    
   public void ite()   
   {    for(int numero:numeros){
       System.out.print(numero);}
    }
   
   
}



// // Devuelve el numero de elementos del ArrayList
// nombreArrayList.size();

// // Devuelve el elemento que esta en la posición '2' del ArrayList
// nombreArrayList.get(2);

// // Comprueba se existe del elemento ('Elemento') que se le pasa como parametro
// nombreArrayList.contains("Elemento");

// // Devuelve la posición de la primera ocurrencia ('Elemento') en el ArrayList  
// nombreArrayList.indexOf("Elemento");

// // Devuelve la posición de la última ocurrencia ('Elemento') en el ArrayList   
// nombreArrayList.lastIndexOf("Elemento");

// // Borra el elemento de la posición '5' del ArrayList   
// nombreArrayList.remove(5); 

// // Borra la primera ocurrencia del 'Elemento' que se le pasa como parametro.  
// nombreArrayList.remove("Elemento");

// //Borra todos los elementos de ArrayList   
// nombreArrayList.clear();

// // Devuelve True si el ArrayList esta vacio. Sino Devuelve False   
// nombreArrayList.isEmpty();  
