import java.util.Scanner; 
import java.util.regex;
public class descadena
{
   

    
    
    
    
    
  // Scanner lector = new Scanner(System.in);
   //String linea =lector.nextLine(); 
//    String cadena = "sdfsadfasf";
//    
//    String[] arreglostring ;
//    arreglostring = cadena.split();
//     
     
    
//     for (int i = 0; i < cadena.length; i++)
//     {
//         char letra = cadena.charAt(i);        
// } 
   
   //HashSet<String> palabras =  new HashSet<String>();
   //for(String palabra : arregloDePalabras)
   //{palabras.add(palabra); }
   //return palabras; 

  }
