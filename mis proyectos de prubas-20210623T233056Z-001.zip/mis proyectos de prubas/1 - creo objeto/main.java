import java.util.Scanner; //uso del cin en java

public class main
{
    private  pruebaobjeto a;
 
    public main()
    {
        
        
        a = new pruebaobjeto();
        
        System.out.print("mi x por defecto es: "+a.getx()+ "...");
        
        
        Scanner abc = new Scanner(System.in);
        System.out.print("Ingreso mi nueva x:");
        int c = abc.nextInt();
        
        a.setx(c);//seteo
        
        System.out.print("mi x  es:") ;
        a.getx();
        
    }

   
}
