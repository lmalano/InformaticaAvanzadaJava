

public class pruebaobjeto
{
    // instance variables - replace the example below with your own
    private int x;
    private int y;
    public String saludo;

    pruebaobjeto()
    {
    x=5;
    y=15;
    saludo="hola";
   
    }
    
    public void setx(int a)
    {
        x=a;
    }

    
    public void sety(int b)
    {
        y=b;
    }
    
     public void setSring(String abc)
    {
    saludo=abc;    
    }
    
    public int getx()
    {
        return x;
    }

      public int gety()
    {
        return y;
    }
    
    public String getSring()
    {
    return saludo;   
    }
    
}
