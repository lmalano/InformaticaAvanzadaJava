import java.util.*;



public class ab
{
    // instance variables - replace the example below with your own
    private ArrayList<Integer> a;

    boolean d=false;
    
    /**
     * Constructor for objects of class ab
     */
    public ab()
    {
        a= new ArrayList<Integer>();
    }

    public ArrayList get()
    {return a;}
    
    public void adds(int b)
    {a.add(b);}
    
    public void ite()   
   {    for(int alfalfita:a){
       System.out.print(alfalfita+" ");}
    }
    
   public boolean busca(int e){
    for(int alfalfita:a){
        if(a.contains(e))
        {d=true;}
        else
        {d=false;}
    }
    return d;
    }
    
    
}
