import java.util.HashSet;
import java.util.Iterator;
import java.util.ArrayList;

public class hastset
{
    // instance variables - replace the example below with your own
    private HashSet<String> miConjunto;

    public hastset()
    {
       
       miConjunto = new HashSet<String>();
       miConjunto.add("uno");
       miConjunto.add("dos");
       miConjunto.add("tres"); 
       
       System.out.println(miConjunto.size());//devuelve tamaño
     System.out.println(miConjunto.contains("uno"));
       
        Iterator<String> it = miConjunto.iterator();
        while(it.hasNext()) {//si hay siguiente hago la accion
             it.next(); //siguiente
             System.out.println();
        }
        
    ArrayList<String> list = new ArrayList<>();
	list.add("socrates");
	list.add("plato");
	list.add("cebes");
	list.add("caca");

	// Add all elements to HashSet.
	HashSet<String> nuevo = new HashSet<>();
	nuevo.addAll(list);//mete todos los elementos del array al hashset
	 System.out.println(nuevo.size());
	
}
}
    