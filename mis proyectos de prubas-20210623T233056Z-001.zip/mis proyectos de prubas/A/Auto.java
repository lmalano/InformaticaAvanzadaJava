
/**
 * Write a description of class auto here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Auto
{
    private int anio;
    private Color color;
    private String marca;
    private String modelo; 
     
    /**
     * Constructor for objects of class auto
     */
    public Auto(int anio,String marca, String modelo)
    {
        this.anio=anio;
        this.marca=marca;
        this.modelo=modelo;
       
    }

   
    public void setanio (int anio)
    {
        this.anio=anio;
        
    }
    
    public void setmarca (String marca)
    {
        this.marca=marca;
        
    }
    
    public void setmodelo (String modelo)
    {
        this.modelo=modelo;
        
    }
    
    public int getanio ()
    {
        return anio;
        
    }
    
    public String getmarca ()
    {
        return marca;
        
    }
    
    public String getmodelo ()
    {
        return modelo;
        
    }
    public void color()
    {color=Color.BLANCO;}
}
