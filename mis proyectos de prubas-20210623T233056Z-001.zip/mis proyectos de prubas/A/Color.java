
/**
 * Enumeration class color - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Color
{
    ROJO,AZUL,PLATEADO,BLANCO,NEGRO
}
