import java.util.*;


/**
 * Write a description of class Fabricante here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fabricante
{
    
   
    
    HashMap<Auto,Integer> autosfcados;
   
    /**
     * Constructor for objects of class Fabricante
     */
    public Fabricante()
    {
        autosfcados = new HashMap<Auto,Integer> ();
        
    }
    
    public void agregarauto(Auto auto,int nrofabricados)
    {
    if(nrofabricados>0 && nrofabricados<50)
    {autosfcados.put(auto,nrofabricados);}
    else
    {throw new IllegalArgumentException();}
    
    
}

public boolean verificarauto(Auto auto,String a)
   {
    if(auto.getmarca().equals(a))
    return true;
    else
    {return false;}    
    }


}
