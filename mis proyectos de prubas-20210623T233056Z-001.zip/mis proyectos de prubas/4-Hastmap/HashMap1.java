import java.util.HashMap;
import java.util.Iterator;

public class HashMap1
{  private HashMap <String, String> a;
   
   //(llave , valor)
   {
    
    a= new HashMap<String, String>();
    
     a.put("casa","linda y chica");
     a.put("auto","peugeot");
     a.put("color","rojo");
     a.put("animal","perro");
     a.put("pais","Argentina");
     
   String ab = a.get("casa");//obtengo hola
   System.out.println(ab);
    
   System.out.println("Mostramos el numero de elementos del TreeMap = "+a.size());
     System.out.println(a.keySet());
   System.out.println("Vemos si el TreeMap esta vacio = "+a.isEmpty());
   System.out.println("Borramos un elemento del Map "+a.remove("auto"));
   System.out.println("Mostramos el numero de elementos del TreeMap = "+a.size());
 
   System.out.println("Vemos que pasa si queremos obtener la clave de casa  = "+a.get("casa"));
   System.out.println("Vemos si existe un elemento con la clave color = "+a.containsKey("color"));
   System.out.println("Vemos si existe el valo 'perro' en el Mapa  = "+a.containsValue("perro"));
   System.out.println("Borramos todos los elementos del Map nuevamente");a.clear();
   System.out.println("Comprobamos si lo hemos eliminado viendo su tamaño = "+a.size());
   System.out.println("Lo comprobamos tambien viendo si esta vacio = "+a.isEmpty());
   System.out.println(a.keySet());
    }
    
  
   
   
}



//String numeroTelefonico = agenda.get("Lisa Jones");
//System.out.println(numeroTeleonico);