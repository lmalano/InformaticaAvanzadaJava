import java.util.HashMap;
import java.util.Iterator;

public class main
{
  main()
  {
      HashMap <String, String> b= new HashMap<String, String>();
      insertar(b,"casa","blanca");
      insertar(b,"auto","rojo");
      //mostrar(b,"casa");
    
    }
    
  void insertar(HashMap b,String mensaje1,String mensaje2)
  {
    b.put(mensaje1,mensaje2);
    
    
    }
   
  void mostrar(HashMap b,String ckey)
  {
   //String r= b.get(ckey);
   //return r;
    
    
    }
    
   
   
    
    

   

}
