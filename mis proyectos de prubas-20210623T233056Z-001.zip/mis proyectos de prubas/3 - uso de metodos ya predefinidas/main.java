import java.util.Scanner; //uso del cin en java
import java.lang.String;
public class main
{
    
 
    public main()
    {
 
        Scanner abc = new Scanner(System.in);
        System.out.print("ingrese su texto : ");
        String texto = abc.toLowerCase();//.toLowerCase() -->me convierte todo el texto a minuscula
        System.out.println(texto.charAt(2));//me devuelve el caracter de la posicion 2 x ej
        
        String nvacadena= texto.concat("---concatenacion");//concateno dos cadenas
        System.out.println(nvacadena);
        
       if(texto.equals("abc"))//compara dos string
       {System.out.println("son iguales");}
       if(texto.contains("hola"))//verifica q el texto ingresado sea un hola y si lo es dice holaa
       {System.out.println("holaa");}
       if(texto.contains("a"))//si alguna palabra q ingrese tiene!! con aba me corrige el msj
       {System.out.println("quizo decir acelga,casa, cama, masa?");}
       if(texto.startsWith("adera"))//si la palabra empieza con adera me tira el msj
       {System.out.println("quizo decir madera?");}
    }

   
}      
       
    


    


      