
public class Fecha implements Comparable<Fecha> {

	private int diaDelAnio;
	private int anio;
	
	/**
	 * Constructor. Inicializa las variables
	 * @param diaDelAnio El dia del año, 1 a 365
	 * @param anio El año, entre 2000 y 2100
	 * @throws IllegalArgumentException si los parametros
	 * estan por fuera de los limites especificados 
	 */
	public Fecha (int diaDelAnio, int anio)
	{
		if(diaDelAnio > 365 || diaDelAnio < 1 || anio > 2100 || anio < 2000)
		{
		    throw new IllegalArgumentException();
		}
		else
		{
		    this.diaDelAnio = diaDelAnio;
		    this.anio = anio;
		}
	}

	/**
	 * 
	 * @return el dia del año, entre 1 y 365
	 */
	public int getDiaDelAnio() {
		return diaDelAnio;
	}

	/**
	 * 
	 * @return el año de la fecha
	 * 
	 */
	public int getAnio() {
		return anio;
	}

	@Override
	public int compareTo(Fecha otra) {
		// Retorna un valor negativo, cero, o positivo si esta (this) Fecha es
		// menor, igual o mayor que la "otra" fecha especificada
		return anio*365 + diaDelAnio 
				- (otra.getAnio()*365 + otra.getDiaDelAnio());
	}
	
	@Override
	public boolean equals (Object otra){
		if (otra == null || !(otra instanceof Fecha))
			return false;
		if (this.anio == ((Fecha)otra).getAnio() 
				&& this.diaDelAnio == ((Fecha)otra).getDiaDelAnio())  
			return true;
		return false;
	}
	
}
