
/**
 * Write a description of class MedidorDomiciliario here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MedidorDomiciliario extends Medidor
{
    
    /*Constructor*/
    public MedidorDomiciliario(CoordenadaGPS coordenadas)
    {
        super(coordenadas);
    }

    public  TipoMedidor getTipoMedidor()
    {
        return TipoMedidor.DOMICILIARIO; // retorna el tipo de medidor
    }
    
}
