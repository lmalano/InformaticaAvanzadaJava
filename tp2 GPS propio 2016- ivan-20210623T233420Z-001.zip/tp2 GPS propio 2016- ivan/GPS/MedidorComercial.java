
/**
 * Write a description of class MedidorComercial here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MedidorComercial extends Medidor
{

    /**
     * Constructor for objects of class MedidorComercial
     */
    public MedidorComercial(CoordenadaGPS coordenadas)
    {
        super(coordenadas);
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public  TipoMedidor getTipoMedidor()
    {
        return TipoMedidor.COMERCIAL;
    }
}
